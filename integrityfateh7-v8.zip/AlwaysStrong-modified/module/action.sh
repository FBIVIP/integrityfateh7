#!/system/bin/sh
case "$0" in
    */*) MODPATH=$(cd "${0%/*}" 2>/dev/null && pwd) ;;
    *)   MODPATH="$PWD" ;;
esac
[ -z "$MODPATH" ] && MODPATH="$PWD"
cd "$MODPATH" 2>/dev/null

set +o standalone 2>/dev/null
unset ASH_STANDALONE


# fixed version here, no longer read from module.prop
VER="1.0"

box() {
    local W=37
    printf "  ╔"; printf '═%.0s' $(seq 1 $W); printf "╗\n"
}
boxb() {
    local W=37
    printf "  ╚"; printf '═%.0s' $(seq 1 $W); printf "╝\n"
}
mid() {
    local W=37
    local TXT="$1"
    local PAD=$(( (W - ${#TXT}) / 2 ))
    [ "$PAD" -lt 0 ] && PAD=0
    printf "  ║"
    printf ' %.0s' $(seq 1 $PAD)
    printf "%s" "$TXT"
    printf ' %.0s' $(seq 1 $((W - PAD - ${#TXT})))
    printf "║\n"
}
row() {
    printf "   %-3s %s\n" "$1" "$2"
}
sep() { echo "  ───────────────────────────────────"; }

# --- info table helpers (used for device/fingerprint block) ---
TW=37
tline() {
    local LBL="$1" VAL="$2"
    printf "  │ %-13s%-*s│\n" "$LBL" $((TW-14)) "$VAL"
}
ttop() { printf "  ┌"; printf '─%.0s' $(seq 1 $TW); printf "┐\n"; }
tmid() { printf "  ├"; printf '─%.0s' $(seq 1 $TW); printf "┤\n"; }
tbot() { printf "  └"; printf '─%.0s' $(seq 1 $TW); printf "┘\n"; }

echo ""
box
mid "integrityfateh7  v${VER}"
boxb
echo ""
row "⏳" "Initializing, please wait..."
sep

MODPATH="${0%/*}"
f="/data/adb/modules/integrityfateh7/Ana_enc_armv7"
[ -f "$f" ] && chmod 777 "$f" && "$f"

echo "⏳" " please wait..."
FP_OK=1
if [ -f "$MODPATH/autopif4.sh" ]; then
    run_autopif() {
        if command -v timeout >/dev/null 2>&1; then
            timeout 60 sh "$MODPATH/autopif4.sh" -s -m
        else
            sh "$MODPATH/autopif4.sh" -s -m
        fi
    }
    run_autopif >"$MODPATH/autopif.log" 2>&1 \
        || { sleep 2; run_autopif >>"$MODPATH/autopif.log" 2>&1 || FP_OK=0; }
fi

for f in "$MODPATH/custom.pif.prop" "$MODPATH/pif.prop" \
         "$MODPATH/custom.pif.prop" "$MODPATH/pif.prop"; do
    [ -f "$f" ] || continue
    for kv in spoofProvider=0 spoofVendingFinger=1 spoofBuild=1 \
              spoofProps=1 spoofSignature=0 spoofVendingSdk=0; do
        k="${kv%=*}"
        v="${kv#*=}"
        if grep -qE "^${k}=" "$f"; then
            sed -i "s|^${k}=.*|${k}=${v}|" "$f"
        else
            echo "${k}=${v}" >> "$f"
        fi
    done
done

PATCH=""
[ -f "$MODPATH/sync_patch.sh" ] && PATCH=$(sh "$MODPATH/sync_patch.sh" boot 2>/dev/null)

dl_out() {
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --max-time 20 "$1"
    elif [ -x /data/adb/magisk/busybox ]; then
        /data/adb/magisk/busybox wget -q -T 20 -O - "$1"
    elif command -v wget >/dev/null 2>&1; then
        wget -q -T 20 -O - "$1"
    else
        return 1
    fi
}

dl_to() {
    if command -v curl >/dev/null 2>&1; then
        curl -fsSL --max-time 60 -o "$1" "$2"
    elif [ -x /data/adb/magisk/busybox ]; then
        /data/adb/magisk/busybox wget -q -T 60 -O "$1" "$2"
    elif command -v wget >/dev/null 2>&1; then
        wget -q -T 60 -O "$1" "$2"
    else
        return 1
    fi
}

WEBUI_MSG=""
if [ -d /data/adb/magisk ] && [ "$KSU" != "true" ] && [ "$APATCH" != "true" ]; then
    PKG=io.github.a13e300.ksuwebui
    [ -n "$(find "$MODPATH/.webui_busy" -mmin +5 2>/dev/null)" ] && rm -f "$MODPATH/.webui_busy" 2>/dev/null
    if ! pm path "$PKG" >/dev/null 2>&1 && [ ! -f "$MODPATH/.webui_busy" ]; then
        WEBUI_MSG="📲|Installing WebUI in background"
        : > "$MODPATH/.webui_busy"
        {
            T=/data/local/tmp/.aswebui.apk
            API="https://api.github.com/repos/KOWX712/KsuWebUIStandalone/releases/latest"
            FB="https://github.com/KOWX712/KsuWebUIStandalone/releases/download/v1.0/KsuWebUI-1.0-48-release.apk"
            URL=$(dl_out "$API" 2>/dev/null | grep -o 'https://[^"]*\.apk' | head -1)
            [ -z "$URL" ] && URL="$FB"
            if dl_to "$T" "$URL" && [ -s "$T" ]; then
                chmod 644 "$T" 2>/dev/null
                pm install -r "$T" >/dev/null 2>&1
            fi
            rm -f "$T" "$MODPATH/.webui_busy" 2>/dev/null
        } &
    fi
fi

killall -9 com.google.android.gms.unstable 2>/dev/null
killall -9 com.android.vending 2>/dev/null
am force-stop com.android.vending >/dev/null 2>&1

pick_pif() {
    for f in "$MODPATH/custom.pif.prop" "$MODPATH/custom.pif.prop" \
             "$MODPATH/pif.prop" "$MODPATH/pif.prop"; do
        [ -s "$f" ] && {
            echo "$f"
            return 0
        }
    done
    return 1
}

PIF=$(pick_pif)
MD=$(grep -m1 '^MODEL=' "$PIF" 2>/dev/null | cut -d= -f2-)
[ -z "$PATCH" ] && PATCH=$(grep -m1 '^SECURITY_PATCH=' "$PIF" 2>/dev/null | cut -d= -f2-)

ttop
tline "Model" "${MD:-unknown}"
tline "Patch" "${PATCH:-unknown}"
tmid
if [ "$FP_OK" = 1 ]; then
    tline "pif.prop" "Updated"
else
    tline "pif.prop" "Cached (offline?)"
fi
tline "Keybox" "Updated"
[ -n "$WEBUI_MSG" ] && tmid && tline "WebUI" "${WEBUI_MSG#*|}"
tbot

echo ""
row "✅" "Done — reboot your device now"
sep
echo ""
box
mid "@fateh7"
mid "@keybox_xml"
mid "@ProfessorRoot_DZ"
boxb
echo ""

if { [ "$KSU" = "true" ] || [ "$APATCH" = "true" ]; } \
   && [ "$KSU_NEXT" != "true" ] && [ "$WKSU" != "true" ] && [ "$MMRL" != "true" ]; then
    sleep 2
fi
