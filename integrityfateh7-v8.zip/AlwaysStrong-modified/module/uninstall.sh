#!/system/bin/sh
# integrityfateh7 uninstall — clean every artifact we created.

MODDIR=${0%/*}

# Kill all running module processes
for proc in TEESimulator supervisor daemon; do
    for pid in $(pidof "$proc" 2>/dev/null); do
        kill -9 "$pid" 2>/dev/null
    done
done
pkill -9 -f TEESimulator 2>/dev/null || true
pkill -9 -f org.matrix.TEESimulator 2>/dev/null || true

# Kill GMS + Vending so they reload without our hooks
killall -9 com.google.android.gms.unstable 2>/dev/null
killall -9 com.google.android.gms 2>/dev/null
am force-stop com.android.vending 2>/dev/null

# Wipe TEESimulator runtime state

# Global PIF prop we dropped for the TEE PatchLevelManager (sync_patch.sh)
rm -f /data/adb/pif.prop

# Remove any stale playintegrityfix folder left by older shim-based builds
rm -rf /data/adb/modules/playintegrityfix 2>/dev/null

# Config files are user-managed; nothing to clean here.
